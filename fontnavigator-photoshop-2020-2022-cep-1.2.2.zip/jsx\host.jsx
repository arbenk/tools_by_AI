#target photoshop

var FontNavigator = (function () {
    var s2t = stringIDToTypeID;
    var c2t = charIDToTypeID;
    var pendingSource = "";
    var pendingTarget = null;
    var pendingChanged = 0;

    function escapeString(value) {
        return '"' + String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '"';
    }

    function stringify(value) {
        if (value === null) return "null";
        if (typeof value === "string") return escapeString(value);
        if (typeof value === "number" || typeof value === "boolean") return String(value);
        if (value instanceof Array) {
            var items = [];
            for (var i = 0; i < value.length; i++) items.push(stringify(value[i]));
            return "[" + items.join(",") + "]";
        }
        var pairs = [];
        for (var key in value) if (value.hasOwnProperty(key)) pairs.push(escapeString(key) + ":" + stringify(value[key]));
        return "{" + pairs.join(",") + "}";
    }

    function success(data) { return stringify({ ok: true, data: data }); }
    function failure(error) { return stringify({ ok: false, error: error && error.message ? error.message : String(error) }); }

    function getTextDescriptor(layerId) {
        var reference = new ActionReference();
        reference.putProperty(c2t("Prpr"), s2t("textKey"));
        reference.putIdentifier(c2t("Lyr "), layerId);
        var result = executeActionGet(reference);
        return result.getObjectValue(s2t("textKey"));
    }

    function styleInfo(style) {
        var ps = style.hasKey(s2t("fontPostScriptName")) ? style.getString(s2t("fontPostScriptName")) : "";
        var family = style.hasKey(s2t("fontName")) ? style.getString(s2t("fontName")) : ps;
        var fontStyle = style.hasKey(s2t("fontStyleName")) ? style.getString(s2t("fontStyleName")) : "";
        return ps || family ? { postScriptName: ps || family, family: family || ps, style: fontStyle } : null;
    }

    function fontsInDescriptor(text) {
        var result = {}, key, i, range, style, info;
        if (text.hasKey(s2t("textStyle"))) {
            info = styleInfo(text.getObjectValue(s2t("textStyle")));
            if (info) result[info.postScriptName] = info;
        }
        if (text.hasKey(s2t("textStyleRange"))) {
            var ranges = text.getList(s2t("textStyleRange"));
            for (i = 0; i < ranges.count; i++) {
                range = ranges.getObjectValue(i);
                if (!range.hasKey(s2t("textStyle"))) continue;
                style = range.getObjectValue(s2t("textStyle"));
                info = styleInfo(style);
                if (info) result[info.postScriptName] = info;
            }
        }
        return result;
    }

    function readableFontName(family, style, fallback) {
        var readableFamily = String(family || fallback || "");
        var readableStyle = String(style || "");
        if (!readableStyle) return readableFamily;
        if (readableFamily.toLowerCase().indexOf(readableStyle.toLowerCase()) !== -1) return readableFamily;
        return readableFamily + " " + readableStyle;
    }

    function installedFontMap() {
        var result = {};
        for (var i = 0; i < app.fonts.length; i++) {
            var font = app.fonts[i];
            result[font.postScriptName] = {
                displayName: readableFontName(font.family, font.style, font.name || font.postScriptName),
                family: font.family,
                style: font.style,
                postScriptName: font.postScriptName
            };
        }
        return result;
    }

    function collectTextLayers(container, output) {
        for (var i = 0; i < container.layers.length; i++) {
            var layer = container.layers[i];
            if (layer.typename === "LayerSet") collectTextLayers(layer, output);
            else if (layer.typename === "ArtLayer" && layer.kind === LayerKind.TEXT) output.push({ id: layer.id, name: layer.name });
        }
    }

    function scanDocument() {
        try {
            if (!app.documents.length) throw new Error("当前没有打开的 Photoshop 文档。");
            var layers = [], map = {}, order = [], installed = installedFontMap();
            collectTextLayers(app.activeDocument, layers);
            for (var i = 0; i < layers.length; i++) {
                var layer = layers[i], found = fontsInDescriptor(getTextDescriptor(layer.id));
                for (var ps in found) if (found.hasOwnProperty(ps)) {
                    if (!map[ps]) {
                        var known = installed[ps];
                        map[ps] = {
                            postScriptName: ps,
                            displayName: known ? known.displayName : readableFontName(found[ps].family, found[ps].style, ps),
                            family: known ? known.family : found[ps].family,
                            style: known ? known.style : found[ps].style,
                            layers: []
                        };
                        order.push(ps);
                    }
                    map[ps].layers.push({ id: layer.id, name: layer.name });
                }
            }
            var fonts = [];
            for (i = 0; i < order.length; i++) fonts.push(map[order[i]]);
            return success({ fonts: fonts });
        } catch (error) { return failure(error); }
    }

    function getInstalledFonts() {
        try {
            var fonts = [];
            for (var i = 0; i < app.fonts.length; i++) {
                var font = app.fonts[i];
                fonts.push({ postScriptName: font.postScriptName, displayName: readableFontName(font.family, font.style, font.name || font.postScriptName), family: font.family, style: font.style });
            }
            function nameGroup(name) {
                var first = String(name || "").charAt(0);
                if (/[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]/.test(first)) return 0;
                if (/[A-Za-z]/.test(first)) return 1;
                return 2;
            }
            fonts.sort(function (a, b) {
                var aName = a.displayName || a.family || a.postScriptName;
                var bName = b.displayName || b.family || b.postScriptName;
                var groupDifference = nameGroup(aName) - nameGroup(bName);
                if (groupDifference) return groupDifference;
                aName = aName.toLowerCase(); bName = bName.toLowerCase();
                if (aName === bName) return 0;
                return aName < bName ? -1 : 1;
            });
            return success(fonts);
        } catch (error) { return failure(error); }
    }

    function selectLayer(layerId) {
        try {
            var reference = new ActionReference(); reference.putIdentifier(c2t("Lyr "), Number(layerId));
            var descriptor = new ActionDescriptor(); descriptor.putReference(c2t("null"), reference); descriptor.putBoolean(c2t("MkVs"), false);
            executeAction(c2t("slct"), descriptor, DialogModes.NO);
            return success(true);
        } catch (error) { return failure(error); }
    }

    function targetFontInfo(postScriptName) {
        for (var i = 0; i < app.fonts.length; i++) if (app.fonts[i].postScriptName === postScriptName) {
            return { postScriptName: app.fonts[i].postScriptName, family: app.fonts[i].family, style: app.fonts[i].style };
        }
        throw new Error("找不到目标字体：" + postScriptName);
    }

    function replaceStyle(style) {
        var current = styleInfo(style);
        if (!current || current.postScriptName !== pendingSource) return false;
        style.putString(s2t("fontPostScriptName"), pendingTarget.postScriptName);
        style.putString(s2t("fontName"), pendingTarget.family);
        style.putString(s2t("fontStyleName"), pendingTarget.style);
        return true;
    }

    function replaceLayer(layerId) {
        var text = getTextDescriptor(layerId), changed = false, i;
        if (text.hasKey(s2t("textStyle"))) {
            var baseStyle = text.getObjectValue(s2t("textStyle"));
            if (replaceStyle(baseStyle)) { text.putObject(s2t("textStyle"), s2t("textStyle"), baseStyle); changed = true; }
        }
        if (text.hasKey(s2t("textStyleRange"))) {
            var oldRanges = text.getList(s2t("textStyleRange")), newRanges = new ActionList();
            for (i = 0; i < oldRanges.count; i++) {
                var range = oldRanges.getObjectValue(i);
                if (range.hasKey(s2t("textStyle"))) {
                    var style = range.getObjectValue(s2t("textStyle"));
                    if (replaceStyle(style)) { range.putObject(s2t("textStyle"), s2t("textStyle"), style); changed = true; }
                }
                newRanges.putObject(s2t("textStyleRange"), range);
            }
            if (changed) text.putList(s2t("textStyleRange"), newRanges);
        }
        if (!changed) return false;
        var reference = new ActionReference(); reference.putIdentifier(c2t("Lyr "), layerId);
        var setDescriptor = new ActionDescriptor(); setDescriptor.putReference(c2t("null"), reference); setDescriptor.putObject(c2t("T   "), s2t("textLayer"), text);
        executeAction(c2t("setd"), setDescriptor, DialogModes.NO);
        return true;
    }

    function replacePending() {
        var layers = []; collectTextLayers(app.activeDocument, layers); pendingChanged = 0;
        for (var i = 0; i < layers.length; i++) if (replaceLayer(layers[i].id)) pendingChanged++;
    }

    function replaceFont(source, target) {
        try {
            if (!app.documents.length) throw new Error("当前没有打开的 Photoshop 文档。");
            pendingSource = String(source); pendingTarget = targetFontInfo(String(target)); pendingChanged = 0;
            app.activeDocument.suspendHistory("批量替换字体", "FontNavigator._replacePending()");
            return success({ changedLayers: pendingChanged });
        } catch (error) { return failure(error); }
    }

    return { scanDocument: scanDocument, getInstalledFonts: getInstalledFonts, selectLayer: selectLayer, replaceFont: replaceFont, _replacePending: replacePending };
}());
